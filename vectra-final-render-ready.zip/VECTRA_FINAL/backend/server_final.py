
import os
from fastapi import FastAPI, HTTPException, Depends, Cookie
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, List, Dict
import uuid, time

app = FastAPI(title="Vectra AI - Swastik AI Labs")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# In-memory DB (replaces MongoDB for preview)
DB = {
    "users": {},
    "sessions": {},
    "projects": {},
    "media": {},
    "video_jobs": {},
    "oauth_tokens": {},
    "performance_tasks": {}
}

FOUNDER_EMAILS = [e.strip().lower() for e in os.getenv("FOUNDER_EMAILS", "akhil718@gmail.com").split(",")]

def resolve_role(email: str, db_role: str = "user"):
    if email.lower() in FOUNDER_EMAILS:
        return "founder"
    return db_role or "user"

class RegisterIn(BaseModel):
    email: str
    password: str
    name: Optional[str] = "User"

class LoginIn(BaseModel):
    email: str
    password: str

def get_current_user(session_id: str = Cookie(None)):
    if not session_id or session_id not in DB["sessions"]:
        raise HTTPException(status_code=401, detail="Not authenticated")
    user_id = DB["sessions"][session_id]
    user = DB["users"].get(user_id)
    if not user:
        raise HTTPException(status_code=401)
    return user

@app.post("/api/auth/register")
def register(data: RegisterIn):
    for u in DB["users"].values():
        if u["email"].lower() == data.email.lower():
            raise HTTPException(400, "Email exists")
    uid = str(uuid.uuid4())
    role = resolve_role(data.email, "user")
    DB["users"][uid] = {"id": uid, "email": data.email, "name": data.name, "role": role, "password": data.password}
    sid = str(uuid.uuid4())
    DB["sessions"][sid] = uid
    return {"user": {k: v for k, v in DB["users"][uid].items() if k != "password"}, "session_id": sid}

@app.post("/api/auth/login")
def login(data: LoginIn):
    user = None
    for u in DB["users"].values():
        if u["email"].lower() == data.email.lower() and u["password"] == data.password:
            user = u
            break
    if not user:
        raise HTTPException(401, "Invalid credentials")
    user["role"] = resolve_role(user["email"], user.get("role"))
    sid = str(uuid.uuid4())
    DB["sessions"][sid] = user["id"]
    return {"user": {k: v for k, v in user.items() if k != "password"}, "session_id": sid}

@app.post("/api/auth/logout")
def logout(session_id: str = Cookie(None)):
    if session_id in DB["sessions"]:
        del DB["sessions"][session_id]
    return {"ok": True}

@app.get("/api/auth/me")
def me(current_user: dict = Depends(get_current_user)):
    return {"user": {k: v for k, v in current_user.items() if k != "password"}}

# Projects
class ProjectIn(BaseModel):
    name: str
    description: Optional[str] = ""

@app.post("/api/projects")
def create_project(data: ProjectIn, user=Depends(get_current_user)):
    pid = str(uuid.uuid4())
    DB["projects"][pid] = {"id": pid, "user_id": user["id"], "name": data.name, "description": data.description, "created_at": time.time()}
    return DB["projects"][pid]

@app.get("/api/projects")
def list_projects(user=Depends(get_current_user)):
    return [p for p in DB["projects"].values() if p["user_id"] == user["id"]]

# Media
@app.get("/api/media")
def list_media(user=Depends(get_current_user)):
    return [m for m in DB["media"].values() if m["user_id"] == user["id"]]

# Distribution status - real states, no fake analytics
@app.get("/api/distribution/status")
def dist_status(user=Depends(get_current_user)):
    result = {}
    for platform in ["youtube","instagram","facebook"]:
        token = DB["oauth_tokens"].get(f"{user['id']}_{platform}")
        if not token:
            result[platform] = {"platform": platform, "state": "NOT_CONNECTED", "reason": "NOT_CONFIGURED"}
        else:
            result[platform] = token
    return result

# Performance Map
class TaskIn(BaseModel):
    company_id: str
    department_id: str
    team_id: str
    employee_id: str
    employee_type: str = "human"
    kpi_id: str
    title: str
    target: float
    actual: float
    owner: str
    due_date: str
    sla: str
    cost: float
    bottleneck: Optional[str] = None
    exception: Optional[str] = None

@app.post("/api/performance/tasks")
def create_task(data: TaskIn, user=Depends(get_current_user)):
    if user["role"] not in ["founder","admin"]:
        raise HTTPException(403, "Admin only")
    tid = str(uuid.uuid4())
    ach = (data.actual/data.target*100) if data.target else 0
    rag = "GREEN" if ach>=90 else "AMBER" if ach>=70 else "RED"
    doc = data.dict()
    doc.update({"_id": tid, "achievement_percent": ach, "rag": rag})
    DB["performance_tasks"][tid] = doc
    return doc

@app.get("/api/performance/tasks")
def list_tasks(user=Depends(get_current_user)):
    return list(DB["performance_tasks"].values())

# Video Veo - NOT_CONFIGURED until GEMINI_API_KEY
@app.post("/api/video/generate")
def video_generate(prompt: str, user=Depends(get_current_user)):
    if not os.getenv("GEMINI_API_KEY"):
        return {"status": "NOT_CONFIGURED", "message": "GEMINI_API_KEY missing - Veo disabled"}
    job_id = str(uuid.uuid4())
    DB["video_jobs"][job_id] = {"job_id": job_id, "status": "QUEUED", "prompt": prompt}
    return {"job_id": job_id, "status": "QUEUED"}

@app.get("/api/health")
def health():
    return {"status": "ok", "founder_emails": FOUNDER_EMAILS, "veo_model": os.getenv("VEO_MODEL","veo-3.1-generate-preview")}
